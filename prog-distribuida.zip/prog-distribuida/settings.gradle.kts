rootProject.name = "prog-distribuida"
include("ejemplo01_cdi")
include("ejemplo02_jpa")
include("ejemplo03_rest")
