package com.distribuida;

public class Test {
}
