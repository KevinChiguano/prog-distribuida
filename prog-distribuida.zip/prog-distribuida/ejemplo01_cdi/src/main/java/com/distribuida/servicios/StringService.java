package com.distribuida.servicios;

public interface StringService {
    String convert(String src);
}
